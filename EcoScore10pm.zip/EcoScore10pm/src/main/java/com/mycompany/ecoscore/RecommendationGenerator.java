/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecoscore;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author emilychappel
 */
public class RecommendationGenerator {
    // Method to generate personalized recommendations with eco-friendly tips
    public List<String> generateRecommendations(Users user) {
        // Create a List to store the personalized recommendations
        List<String> recommendations = new ArrayList<>();

        // Calculate user’s ecological footprint score using the getCO2Eq method
        double userFootprintScore = user.getCO2Eq();
        System.out.println(userFootprintScore + "step 4");

        // Determine personalized recommendations based on user's ecological footprint measured in CO2 emissions in tons
        if (userFootprintScore > 18) {
            recommendations.add("Your ecological footprint is high. Consider reducing energy consumption, using public transportation, and recycling more.");
        } else if (userFootprintScore > 10) {
            recommendations.add("Your ecological footprint is moderate. Try to use more renewable energy sources and reduce food waste.");
        } else {
            recommendations.add("Your ecological footprint is relatively low. Keep up the good work!");
        }

        // Check specific user data for additional personalized recommendations
        if (user.getElectricBill() > 100) {
            recommendations.add("Choose ENERGY STAR-certified appliances as they are more efficient which reduces the amount of electricity needed. Also use energy-efficient lighting and only turn on the lights when you need to.");
        } else if (user.getElectricBill() > 150) {
            recommendations.add("Your electric bill is quite high consider replacing your current appliances with ENERGY STAR-certified appliances if they aren’t already and try to use your air condition less.");
        }
        if (user.getGasBill() > 50) {
            recommendations.add("In the day rely less on your AC and raise your blinds to take advantage of the sun’s heat or lower your blinds to keep the cold in.");
        }

        if (user.getOilBill() > 100) {
            recommendations.add("Drive more efficiently and slower to improve gas mileage, also if you need to buy a new car, consider buying a hybrid or electric vehicle. You might also want to consider using public transit or carpooling as it is cheaper.");
        } else if (user.getOilBill() > 200){
            recommendations.add("You may be someone who enjoys driving a lot whether it’s the freedom or having to commute to work. Regardless, if you are planning to buy a new car to reduce your oil bill you can still enjoy the driving experience in a hybrid or electric vehicle. If not, drive on the highway more if you need to get somewhere as it’s more fuel-efficient and drive less aggressively as it’s more fuel-efficient and safer for everyone involved.");
        }
        if (user.getSmallFlights() > 2) {
            recommendations.add("Instead of flying on a plane to locations that take less than 2 hours, consider taking a train or taking a car for a road trip as that is not only cheaper for you but also better for the environment and gives the ability to make the journey to the location memorable.");
        }

        if (user.getYearlyMileage() > 15000) {
            recommendations.add("Consider walking or biking to nearby locations instead of taking a car, also consider finding a job closer to your home as it would reduce your yearly mileage if you take your car to work, reduce the amount of time it takes to commute and reduce your oil/electric bill.");
        }

        // returns the list of recommendations
        return recommendations;
    }

}